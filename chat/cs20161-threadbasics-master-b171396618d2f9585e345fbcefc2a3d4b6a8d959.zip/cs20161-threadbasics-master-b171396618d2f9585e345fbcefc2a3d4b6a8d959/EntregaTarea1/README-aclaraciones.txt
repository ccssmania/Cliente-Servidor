Buenas noches ingeniero,

Adjunto encontrará varios archivos.

Existen fuera del código fuente de las tres implementaciones, los generadores de casos de pruebas y además los diferentes casos de prueba con sus respectivos resultados.

Encontrará además un archivo pdf con nuestro artículo, y un archivo en excel para las tablas y graficas puntuales de los resultados particulares de cada caso de prueba.

Jonatan Gutierrez Obando 
José Alejandro Moreno Agudelo