#include <iostream>
#include <functional>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <vector>	
#include <thread>
#include <chrono>
#include <future>
#include <cmath>
using namespace std;
using namespace std::chrono;




void printer(vector< vector <int> >& matrix ){
	cout<<"-------------------------------------\n";
	for(int i=0;i < (int) matrix.size();i++){
		for(int j=0;j < (int) matrix[i].size();j++){
			if(j!=0) cout<<" ";
			// Made it to unify the sizes of the numbers
			if(matrix[i][j]<=9) cout<<0;
			cout<<matrix[i][j];
		}
		cout<<"\n";
	}
	cout<<"-------------------------------------\n";
}

void matrix_product(vector< vector <int> >& matrixA,vector< vector<int> >& matrixB,vector< vector<int> >& matResult){
	//Auxiliary Empty Vector : type int
	vector<int> v;
	//Process
	for(int i = 0 ; i < (int) matrixA.size() ; i++ ){
		matResult.push_back(v);
		for(int j = 0 ; j < (int) matrixB[0].size() ; j++){
			matResult.back().push_back(0);
			for(int k = 0 ; k < (int) matrixA[0].size() ; k++)
				matResult.back().back()+=matrixA[i][k]*matrixB[k][j];	
			
		}
	}
}	

//Simply operation for the product between two vectors
void vector_product(vector<int>& matrixA , vector< vector<int> >& matrixB,int& tileResult, int& Bcolumn){
	for(int i = 0 ; i < (int) matrixA.size() ; i++ ){
		tileResult+=matrixA[i]*matrixB[i][Bcolumn];
	}
}


vector< vector<int> > productInRange(vector< vector<int> >& matrixA , vector< vector<int> >& matrixB,const int& start,const int& elements){
	//Auxiliary Empty Vector : type int
	vector<int> v;
	//Result matrix
	vector< vector<int> > matrixR;
	//Auxiliary integer
	int tile;	
	//Process
	for(int i = start ; i < (int) min(start+elements,(int) matrixA.size()) ; i++){
		matrixR.push_back(v);
		for(int j=0 ; j < (int) matrixB[0].size() ; j++ ){
			matrixR.back().push_back(0);
			tile=matrixR.back().back();
			vector_product(matrixA[i],matrixB,tile,j);
			matrixR.back().back()=tile;
		}
	}
	return matrixR;
}

void unify(vector< vector<int> >& A, vector< vector<int> >& B){
	for(int i = 0 ; i < (int) B.size() ; i++) A.push_back(B[i]);	
}

void solver(vector< vector<int> > & matrixA , vector< vector<int> >& matrixB,vector< vector<int> >& matrixR){
//Supported
	cout << "Hardware supports " << thread::hardware_concurrency() << " threads"
       << endl;
    int cores = thread::hardware_concurrency();

	int size_of_partitions= max(1,(int) ceil(matrixA.size()/(1.0*cores)));
	//cout<< size_of_partitions << endl;
	int interval=0;
	//threads	
	vector< future< vector< vector<int> > > > v;
	//threads
	for(int i = 0; i < cores ; i++,interval+=size_of_partitions){
		v.push_back(async(productInRange,ref(matrixA),ref(matrixB),interval,size_of_partitions));
	}
	vector< vector<int> > temporal;
	for(int i = 0; i < (int) v.size(); i++){
		temporal=v[i].get();
		unify(matrixR,temporal);
	}
}




void start(vector< vector<int> >& matA,vector< vector<int> >& matB){
	//Dimensions of the first matrix
	int matA_rows,matA_cols;
	//Dimensions of the second matrix
	int matB_rows,matB_cols;
	//Standar input from program:
	cin >> matA_rows >> matA_cols >> matB_rows >> matB_cols;
	//Checking Errors:
	if(matA_cols != matB_rows){
		cerr << "Incompatible dimensions for this operation" << endl;
		return;
	}
	vector <int> v;
	int tile;
	for(int i = 0 ;  i < matA_rows ; i++){
		matA.push_back(v);
		for(int j = 0; j < matA_cols ; j++){
			cin >> tile;
			matA.back().push_back(tile);
		} 
	}
	for(int i = 0 ;  i < matB_rows ; i++){
		matB.push_back(v);
		for(int j = 0; j < matB_cols ; j++){
			cin >> tile;
			matB.back().push_back(tile);
		} 
	}
}




int main(){
	
	ios_base::sync_with_stdio(false); cin.tie(NULL);
	//Matrix A: type data -> int
	vector< vector<int> > matA;
	//Matrix B: type data -> int
	vector< vector<int> > matB;
	//Resulting Matrix: type data -> int
	vector< vector<int> > matResult;
	//Initializing statements from program
	start(matA,matB);
	//Product of matrices A and B
	//matrix_product(matA,matB,matResult); // that's for non parallel implementation
	high_resolution_clock::time_point t1 = high_resolution_clock::now();
	solver(matA,matB,matResult);
	high_resolution_clock::time_point t2 = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>( t2 - t1 ).count();
    cout << "Time for execution: " << duration <<" microseconds\n";
    //Printing the matrix "matResult" which stocks the result of the operation
	cout<< "Resultant Matrix Dimensions :" << matResult.size() << " " << matResult[0].size() << "\n";
	//printer(matResult);
	return 0;
}