#include <iostream>
#include <functional>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <vector>	
#include <chrono>

using namespace std;
using namespace chrono;



void generate_values(vector< vector<int> > &matrix,int& row,int& col){
	//Auxiliary Empty Vector : type int
	vector<int> v;
	//Inserting seed
	srand (time(NULL));
	//Setting values : type int, range 0 to 99
	for(int i=0;i<row;i++){
		matrix.push_back(v);
		for(int j=0;j<col;j++){
			matrix.back().push_back(rand()%100);
		}
	}
}


void printer(vector< vector <int> >& matrix ){
	cout<<"-------------------------------------\n";
	for(int i=0;i < (int) matrix.size();i++){
		for(int j=0;j < (int) matrix[i].size();j++){
			if(j!=0) cout<<" ";
			// Made it to unify the sizes of the numbers
			if(matrix[i][j]<=9) cout<<0;
			cout<<matrix[i][j];
		}
		cout<<"\n";
	}
	cout<<"-------------------------------------\n";
}



void matrix_product(vector< vector <int> >& matrixA,vector< vector<int> >& matrixB,vector< vector<int> >& matResult){
	//Auxiliary Empty Vector : type int
	vector<int> v;
	//Process
	for(int i = 0 ; i < (int) matrixA.size() ; i++ ){
		matResult.push_back(v);
		for(int j = 0 ; j < (int) matrixB[0].size() ; j++){
			matResult.back().push_back(0);
			for(int k = 0 ; k < (int) matrixA[0].size() ; k++){
				matResult.back().back()+=matrixA[i][k]*matrixB[k][j];	
			}
		}
	}
}	




void start(vector< vector<int> >& matA,vector< vector<int> >& matB){
	//Dimensions of the first matrix
	int matA_rows,matA_cols;
	//Dimensions of the second matrix
	int matB_rows,matB_cols;
	//Standar input from program:
	cin >> matA_rows >> matA_cols >> matB_rows >> matB_cols;
	//Checking Errors:
	if(matA_cols != matB_rows){
		cerr << "Incompatible dimensions for this operation" << endl;
		return;
	}
	//Fill the matrix A with random values:
	generate_values(matA,matA_rows,matA_cols);
	//Fill the matrix B with random values:
	generate_values(matB,matB_rows,matB_cols);
	//Print the matrix A
	//printer(matA);
	//Print the matrix B
	//printer(matB);
}




int main(){
	ios_base::sync_with_stdio(false); cin.tie(NULL);
	//Matrix A: type data -> int
	vector< vector<int> > matA;
	//Matrix B: type data -> int
	vector< vector<int> > matB;
	//Resulting Matrix: type data -> int
	vector< vector<int> > matResult;
	//Initializing statements from program
	start(matA,matB);
	//Product of matrices A and B
	high_resolution_clock::time_point t1 = high_resolution_clock::now();
	matrix_product(matA,matB,matResult);
	high_resolution_clock::time_point t2 = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>( t2 - t1 ).count();
    cout << "Time for execution: " << duration <<" microseconds\n";
    //Printing the matrix "matResult" which stocks the result of the operation
	cout<< "Resultant Matrix Dimensions :" << matResult.size() << " " << matResult[0].size() << "\n";
	//Printing the matrix "matResult" which stocks the result of the operation
	//printer(matResult);
	return 0;
}