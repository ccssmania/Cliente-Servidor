#include <fstream>
#include <iostream>
#include <string>
using namespace std;

string s[10];
char line[4];
string text="";

int main(){
	for(int i=0; i<10;i++) cin>>s[i];
	FILE *archivo;
	archivo= fopen("Resultados.txt", "a");
	char *c=new char[s[3].size()+1];
	copy(s[3].begin(), s[3].end(),c);
	c[s[3].size()]='\0';
	fprintf(archivo,"%s,\n",c);
	fclose(archivo);
	return 0;
}