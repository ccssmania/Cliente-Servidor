#include <fstream>
#include <iostream>
#include <string>
using namespace std;

string s[14];
char line[4];
string text="";

int main(){
	for(int i=0; i<14;i++) cin>>s[i];
	FILE *archivo;
	archivo= fopen("Resultados.txt", "a");
	char *c=new char[s[7].size()+1];
	copy(s[7].begin(), s[7].end(),c);
	c[s[7].size()]='\0';
	fprintf(archivo,"%s,\n",c);
	fclose(archivo);
	return 0;
}