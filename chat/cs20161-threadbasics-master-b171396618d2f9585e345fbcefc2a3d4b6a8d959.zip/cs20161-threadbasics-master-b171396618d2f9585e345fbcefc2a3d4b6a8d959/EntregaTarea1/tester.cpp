#include <iostream>
#include <functional>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <vector>	
#include <thread>
#include <chrono>
using namespace std::chrono;
using namespace std;

void generate_values(vector< vector<int> > &matrix,int& row,int& col){
	//Auxiliary Empty Vector : type int
	vector<int> v;
	
	//Setting values : type int, range 0 to 99
	for(int i=0;i<row;i++){
		matrix.push_back(v);
		for(int j=0;j<col;j++){
			matrix.back().push_back(rand()%100);
		}
	}
}


void printer(vector< vector <int> >& matrix ){
	for(int i=0;i < (int) matrix.size();i++){
		for(int j=0;j < (int) matrix[i].size();j++){
			if(j!=0) cout<<" ";
			// Made it to unify the sizes of the numbers
			if(matrix[i][j]<=9) cout<<0;
			cout<<matrix[i][j];
		}
		cout<<"\n";
	}
	cout<<"\n";
}


void start(vector< vector<int> >& matA,vector< vector<int> >& matB){
	
	//Dimensions of the first matrix
	int matA_rows,matA_cols;
	//Dimensions of the second matrix
	int matB_rows,matB_cols;
	//Inserting seed
	srand (time(NULL));
	//Generating random values:
	matA_rows=rand()%100;
	matA_cols=rand()%100;
	matB_rows=matA_cols;
	matB_cols=rand()%100;
	//Fill the matrix A with random values:
	generate_values(matA,matA_rows,matA_cols);
	//Fill the matrix B with random values:
	generate_values(matB,matB_rows,matB_cols);
	//Print the dimensions of A and B in order row and column respectively
	cout << matA_rows << " " << matA_cols << " " << matB_rows << " " << matB_cols << "\n";
	//Print the matrix A
	printer(matA);
	//Print the matrix B
	printer(matB);
}




int main(){
	ios_base::sync_with_stdio(false); cin.tie(NULL);
	//Number of test cases
	int n;
	//Standar input from program:
	cin >> n;
	//Matrix A: type data -> int
	vector< vector<int> > matA;
	//Matrix B: type data -> int
	vector< vector<int> > matB;
	//Resulting Matrix: type data -> int
	vector< vector<int> > matResult;
	//Initializing statements from program
	while(n--) start(matA,matB);

}