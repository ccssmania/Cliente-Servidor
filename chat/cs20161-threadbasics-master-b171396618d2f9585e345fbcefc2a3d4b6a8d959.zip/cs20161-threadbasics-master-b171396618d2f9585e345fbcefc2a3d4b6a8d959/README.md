# Thread basics

## Matrix multiplication
In the file _vecadd.cc_ you will find an example on how to use threads to
perform a simple vector computation. This code is your starting point towards a
more compelling exercise: _matrix multiplication_.

Write a C++ program that exploits the hardware parallelism to perform classical
matrix multiplication. Your implementation must take into account the fact that
modern hardware has a significant but yet limitted number of cores. You have to
use these resources smartly.

## Asynchronous matrix multiplication
A higher level of abstraction on threads is provided by the notion of
asynchronous operation. An example of such an abstraction is provided in
_fibo.cc_ where _futures_ are used to *return* values that can be concurrently
computed.

Write a C++ program that uses _futures_ to implement matrix multiplication.
Compare the performance of this approach with the one from the previous exercise
and write your conclusions. It is very important to support them by experimental
data.