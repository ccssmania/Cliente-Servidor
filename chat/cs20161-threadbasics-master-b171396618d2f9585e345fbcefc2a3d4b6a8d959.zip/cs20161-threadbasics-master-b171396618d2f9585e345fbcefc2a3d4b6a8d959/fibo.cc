#include <iostream>
#include <thread>
#include <future>

using namespace std;

int fibonacci(int n) {
  if (n == 0)
    return 1;
  if (n == 1)
    return 1;
  future<int> a(async(fibonacci, n - 1));
  future<int> b(async(fibonacci, n - 2));
  return a.get() + b.get();
}

int main() {
  cout << "Parallelism in the wrong way!" << endl;
  int r = fibonacci(100);
  cout << r << endl;
  return 0;
}