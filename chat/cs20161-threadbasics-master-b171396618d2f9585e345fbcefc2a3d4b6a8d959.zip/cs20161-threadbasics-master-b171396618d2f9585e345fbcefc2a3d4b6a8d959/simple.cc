#include <iostream>
#include <vector>
#include <thread>

using namespace std;

void func(int x) {
  cout << "Inside thread " << x << " thread id " << this_thread::get_id()
       << endl;
}

int main() {
  cout << "Simple threading in c++" << endl;
  cout << "Hardware supports " << thread::hardware_concurrency() << " threads"
       << endl;
  thread th(func, 100);
  th.join();
  cout << "Main thread" << endl;
  cout << "Will launch a hundred threads" << endl;
  vector<thread> ths;
  for (int i = 0; i < 100; i++) {
    ths.push_back(thread(func, i));
  }
  // And will wait for them to finish
  for (auto &t : ths)
    t.join();
  return 0;
}