#include <iostream>
#include <vector>
#include <thread>
#include <functional>

using namespace std;

void vecadd(int scalar, const vector<int> &x, const vector<int> &y,
            vector<int> &z) {
  for (int i = 0; i < x.size(); i++) {
    z[i] = scalar * x[i] + y[i];
  }
}

void pvecadd(int scalar, const vector<int> &x, const vector<int> &y,
             vector<int> &z, int start, int end) {
  for (int i = start; i < end; i++) {
    z[i] = scalar * x[i] + y[i];
  }
}

void print(const vector<int> &v) {
  for (auto i : v)
    cout << " " << i;
  cout << endl;
}

int main() {
  vector<int> x{1, 1, 1, 1}, y{2, 2, 2, 2}, z(4, 0);
  vecadd(1, x, y, z);
  print(z);

  vector<int> w(4, 0);
  thread t1(pvecadd, 1, cref(x), cref(y), ref(w), 0, x.size() / 2);
  thread t2(pvecadd, 1, cref(x), cref(y), ref(w), x.size() / 2, x.size());
  t1.join();
  t2.join();
  print(w);
  return 0;
}